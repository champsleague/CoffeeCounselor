package com.gachon.coffeecounselor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class CafeinfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cafeinfo);

        ImageButton starbucks  = findViewById(R.id.starbucksButton);
        starbucks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(CafeinfoActivity.this, MenuActivity.class);
                startActivity(intent2);
            }
        });

        ImageButton twosome  = findViewById(R.id.twosomeButton);
        twosome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent3 = new Intent(CafeinfoActivity.this, MenuActivity.class);
                startActivity(intent3);
            }
        });

        ImageButton megacoffee  = findViewById(R.id.megacoffeeButton);
        megacoffee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent4 = new Intent(CafeinfoActivity.this, MenuActivity.class);
                startActivity(intent4);
            }
        });

        ImageButton ediya  = findViewById(R.id.ediyaButton);
        ediya.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent5 = new Intent(CafeinfoActivity.this, MenuActivity.class);
                startActivity(intent5);
            }
        });

        ImageButton pascucci  = findViewById(R.id.pascucciButton);
        pascucci.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent6 = new Intent(CafeinfoActivity.this, MenuActivity.class);
                startActivity(intent6);
            }
        });


    }
}